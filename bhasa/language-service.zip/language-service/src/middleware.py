"""Middleware — rate limiting (Redis) + request logging"""
import time
import logging
import os
import json
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

# Try to use Redis; fall back to in-memory if unavailable
try:
    import redis.asyncio as aioredis
    _redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
    _redis = aioredis.from_url(_redis_url, decode_responses=True)
    REDIS_AVAILABLE = True
except Exception:
    REDIS_AVAILABLE = False
    _in_memory: dict = {}

RATE_LIMIT = int(os.getenv("RATE_LIMIT_RPM", 60))   # requests per minute per IP


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path in ("/health", "/docs", "/openapi.json"):
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        key = f"ratelimit:{client_ip}"

        try:
            if REDIS_AVAILABLE:
                count = await _redis.incr(key)
                if count == 1:
                    await _redis.expire(key, 60)
            else:
                now = time.time()
                entry = _in_memory.get(key, {"count": 0, "reset_at": now + 60})
                if now > entry["reset_at"]:
                    entry = {"count": 0, "reset_at": now + 60}
                entry["count"] += 1
                _in_memory[key] = entry
                count = entry["count"]

            if count > RATE_LIMIT:
                raise HTTPException(
                    status_code=429,
                    detail=f"Rate limit exceeded: {RATE_LIMIT} req/min",
                )
        except HTTPException:
            raise
        except Exception as e:
            logger.warning(f"Rate limiter error (allowing request): {e}")

        return await call_next(request)


class RequestLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = round((time.perf_counter() - start) * 1000, 2)

        logger.info(
            json.dumps({
                "method": request.method,
                "path": request.url.path,
                "status": response.status_code,
                "ms": elapsed,
                "ip": request.client.host if request.client else "unknown",
            })
        )
        response.headers["X-Response-Time"] = f"{elapsed}ms"
        return response
